<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\HeroInvitationApiController;

Route::get('/test', function () {
    return response()->json(['message' => 'API route works!']);
});

Route::get('/slug/{id}/hero-invitation', [HeroInvitationApiController::class, 'show']);
